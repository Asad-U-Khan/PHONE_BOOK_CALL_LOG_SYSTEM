This is basically a PhoneBook system with Call log.
This project is built on cpp and features concepts of Data Structures and Algorithms.
Data_Set file has initial data set.
LOGO file is used for console formatting.
Kindly share this more to other people and show some support.
Thanking you!