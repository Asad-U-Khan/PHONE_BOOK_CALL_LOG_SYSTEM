#include <iostream>
#include <string.h>
#include <conio.h>
#include <time.h>
#include <fstream>
#include <windows.h>
#include <stack>
#include <vector>

using namespace std;

//Forward Declarations
class Contact;
void Sub_Menu(Contact*);
void Check_Duplicate(Contact*,string);
void Edit_Call_Log(string,string);
void Main_Menu();
bool num_valid(long long int);

//Constant Declarations
int No_of_Contacts=0;
int H_Contacts=0;
int Blocked_Contacts=0;
int T_Size=997; //Prime numbers are good choice for hashing
const int S_Size=50;
static bool flag=false;
static int disp=1;

// A contact's information
class Contact_Info{
	public:
		string name;
		long long int phone_no;
	    string saved;
	    Contact_Info()
	    {
	    	name=" ";
		    phone_no=0;
		    saved="SIM1";
	    }
	    Contact_Info(string name,long long int phone_no,string saved):name(name),phone_no(phone_no),saved(saved){
	    }
	    void Set_Contact_Info(string name,long long int phone_no,string saved)
	    {
		    this->name=name;
		    this->phone_no=phone_no;
		    this->saved=saved;
	    }
	    ~Contact_Info(){
	    }
};

// A phone_node of Phone_Book AVL
class Contact{
	public:
		Contact_Info ob;
	    Contact *left;
	    Contact *right;
	    int height;
	    Contact()
	    {
		   ob.Set_Contact_Info(" ",0,"SIM1");
		   height=1;
		   left=NULL;
		   right=NULL;
	    }
	    Contact(string name,long long int phone_no,string saved)
	    {
		   ob.Set_Contact_Info(name,phone_no,saved);
		   height=1;
		   left=NULL;
		   right=NULL;
	    }
	    ~Contact(){
	    }
};

Contact *root=NULL;

// AVL tree of Contact phone_nodes (Solves Degeneration issues)
class Phone_Book{
	public:
		int Get_Height(Contact*);
		int Get_Balance(Contact*);
		Contact *Find_Max(Contact*);
		Contact *Right_Rotate(Contact*);
		Contact *Left_Rotate(Contact*);
		Contact *Insert_Contact(Contact*,string,long long int,string);
		void Search_Contact(Contact*,string);
		void Edit_Contact(Contact*,string);
		Contact *Delete_Contact(Contact*,string);
		void Call_Contact(Contact*);
		void Display_Contacts(Contact*);

}obj;

//Contact Hash Table Entry
class H_T_Entry{
	public:
		string name;
		long long int phone_no;
		string saved;
		H_T_Entry *next;
		public:
			H_T_Entry()
			{
				name=" ";
				phone_no=0;
				saved="SIM1";
				next=NULL;
			}
			H_T_Entry(string name,long long int phone_no,string saved):name(name),phone_no(phone_no),saved(saved){
			    next=NULL;
			}
};

//Phone Book Hash Table
class H_Table{
	H_T_Entry **T;
	public:
		H_Table()
		{
			T=new H_T_Entry*[T_Size];
			for(int i=0;i<T_Size;i++)
			{
				T[i]=NULL;
			}
		}
		int Hash_Func(long long int key)
		{
			return (key%T_Size);
		}
		void Insert_Data(string name,long long int phone_no,string saved)
		{
			int hashvalue=Hash_Func(phone_no);
			if(T[hashvalue]==NULL)
			{
				T[hashvalue]=new H_T_Entry(name,phone_no,saved);
			}
			else
			{
			    H_T_Entry *entry=T[hashvalue];
			    while(entry->next!=NULL)
                {
                    entry=entry->next;
                }
                entry->next=new H_T_Entry(name,phone_no,saved);
			}
			H_Contacts++;
			if(H_Contacts/T_Size>0.75) // Load Factor
            {
                Re_Hash();
            }
		}
		void Re_Hash()
		{
		    H_T_Entry **temp;
		    temp=new H_T_Entry*[T_Size];
		    for(int i=0;i<T_Size;i++) //Saving hash table values and clearing original hash table
            {
                temp[i]=T[i];
                T[i]=NULL;
            }
            T=new H_T_Entry*[T_Size*2];
            for(int i=0;i<T_Size;i++) // Re inserting values in Hash Table
            {
                H_T_Entry *entry=temp[i];
                while(entry!=NULL)
                {
                    Insert_Data(entry->name,entry->phone_no,entry->saved);
                    entry=entry->next;
                }
            }

		}
		string Search_Data(long long int key)
		{
			int hashvalue=Hash_Func(key);
			if(T[hashvalue]==NULL)
			{
				cout << "Contact not found";
				return NULL;
			}
			else
			{
			    H_T_Entry *entry=T[hashvalue];
                while(entry!=NULL)
                {
                    if(entry->phone_no==key)
                    {
                        return T[hashvalue]->name;
                    }
                    entry=entry->next;
                }
                cout << "Contact not found";
				return NULL;
			}
		}
		void Delete_Data(long long int key)
		{
			int hashvalue=Hash_Func(key);
			if(T[hashvalue]==NULL)
			{
				cout << "Contact not found";
			}
			else
			{
				H_T_Entry *entry=T[hashvalue];
				H_T_Entry *prev=NULL;
				while(entry->next!=NULL && entry->phone_no!=key)
                {
                    prev=entry;
                    entry=entry->next;
                }
                if(prev==NULL && entry->phone_no==key)
                {
                    H_T_Entry *temp=entry->next;
                    delete entry;
                    T[hashvalue]=temp;
                }
                else if(prev!=NULL && entry->phone_no==key)
                {
                    H_T_Entry *temp=entry->next;
                    delete entry;
                    prev->next=temp;
                }
			}
		}
		void Edit_Data(long long int key,string name,string saved)
		{
			int hashvalue=Hash_Func(key);
			if(T[hashvalue]==NULL)
			{
				cout << "Contact not found";
			}
			else
			{
			    H_T_Entry *entry=T[hashvalue];
                while(entry!=NULL)
                {
                    if(entry->phone_no==key)
                    {
                        entry->name=name;
                        entry->phone_no=key;
                        entry->saved=saved;
                    }
                    entry=entry->next;
                }
			}
		}
}H_obj;

//Block List Node
class Contact_B{
	public:
	Contact_Info obj;
	Contact_B *next;
	Contact_B()
	{
		obj.Set_Contact_Info("",0,"");
		next=NULL;
	}
	Contact_B(string name,long long int phone_no,string saved)
	{
		obj.Set_Contact_Info(name,phone_no,saved);
		next=NULL;
	}
};

//Block List
class Block_List{
	public:
		Contact_B *Initial_B;
		Block_List()
		{
			Initial_B=NULL;
		}
		void Block_Contact(Contact *Initial)
		{
			Blocked_Contacts++;
			No_of_Contacts--;
			Contact_B *temp=new Contact_B(Initial->ob.name,Initial->ob.phone_no,Initial->ob.saved);
			if(Initial_B==NULL)
			{
				Initial_B=temp;
			}
			else
			{
				temp->next=Initial_B;
				Initial_B=temp;
			}
			root=obj.Delete_Contact(root,Initial->ob.name);
			H_obj.Delete_Data(Initial->ob.phone_no);

		}
		void Unblock_Contact(string contact_name)
		{
			Blocked_Contacts--;
			No_of_Contacts++;
			if(Initial_B->obj.name==contact_name)
			{
				root=obj.Insert_Contact(root,Initial_B->obj.name,Initial_B->obj.phone_no,Initial_B->obj.saved);
			    H_obj.Insert_Data(Initial_B->obj.name,Initial_B->obj.phone_no,Initial_B->obj.saved);
			    Un_Save_BlockList(Initial_B);
				Contact_B *temp=Initial_B;
				Initial_B=Initial_B->next;
				delete temp;
			}
			else
			{
				Contact_B *prev=Initial_B;
				Contact_B *curr=Initial_B;

				while(curr->obj.name!=contact_name)
				{
					prev=curr;
					curr=curr->next;
				}
				root=obj.Insert_Contact(root,curr->obj.name,curr->obj.phone_no,curr->obj.saved);
			    H_obj.Insert_Data(curr->obj.name,curr->obj.phone_no,curr->obj.saved);
			    Un_Save_BlockList(curr);
				prev->next=curr->next;
				curr->next=NULL;
				delete curr;
			}
		}

		//Saves a blocked contact in file
		void Save_BlockList(Contact* Initial)
		{
			cout << Initial->ob.name;
			ofstream fout("Block_List.txt",ios::ios_base::app);

			fout << Initial->ob.name;
			fout << Initial->ob.phone_no;
			fout << Initial->ob.saved << endl;

			fout.close();
		}

		//Removes unblocked contact from file
		void Un_Save_BlockList(Contact_B *Initial_B)
		{
			string a=Initial_B->obj.name,line;
			a.append(to_string(Initial_B->obj.phone_no));
			a.append(Initial_B->obj.saved);

			ifstream fin("Block_List.txt");
			ofstream temp("tempblock.txt");

			while (getline(fin,line))
            {
                if(line!=a)
                {
                    temp << line << endl;
                }
            }
            fin.close();
            temp.close();
            remove("Block_List.txt");
            rename("tempblock.txt","Block_List.txt");
		}
		void Display_BlockList()
		{
			Contact_B *temp=Initial_B;
			int i=1;
			while(temp!=NULL)
			{
                cout << "\t\t\t\t   |\t         " << i << ". "<< temp->obj.name << endl;
                cout << "\t\t\t\t   ===========================================\n";
				temp=temp->next;
				i++;
			}
		}
}B_obj;

int Get_Max(int a,int b)
{
	if(a>b)
	{
		return a;
	}
	else if(a<b)
	{
		return b;
	}
	else
	{
		return a;
	}
}

int Phone_Book::Get_Height(Contact* Initial)
{
	if(Initial==NULL)
	{
		return 0;
	}
	else
	{
		return Initial->height;
	}
}

int Phone_Book::Get_Balance(Contact *Initial)
{
	if(Initial==NULL)
	{
		return 0;
	}
	else
	{
		return Get_Height(Initial->left)-Get_Height(Initial->right);
	}
}

Contact* Phone_Book::Right_Rotate(Contact *Initial)
{
	Contact *x=Initial;
	Contact *y=x->left;
	Contact *temp=y->right;

	y->right=x;
	x->left=temp;

	x->height=Get_Max(Get_Height(x->left),Get_Height(x->right))+1;
	y->height=Get_Max(Get_Height(y->left),Get_Height(y->right))+1;
	return y;
}

Contact* Phone_Book::Left_Rotate(Contact *Initial)
{
	Contact *x=Initial;
	Contact *y=x->right;
	Contact *temp=y->left;

	y->left=x;
	x->right=temp;

	x->height=Get_Max(Get_Height(x->left),Get_Height(x->right))+1;
	y->height=Get_Max(Get_Height(y->left),Get_Height(y->right))+1;
	return y;
}

//Inserts a Contact
Contact* Phone_Book::Insert_Contact(Contact *Initial,string name,long long int phone_no,string saved)
{
	if(Initial==NULL)
	{
		Initial=new Contact(name,phone_no,saved);
		No_of_Contacts++;
		H_obj.Insert_Data(name,phone_no,saved);
		return Initial;
	}
	if(name < Initial->ob.name)
	{
		Initial->left=Insert_Contact(Initial->left,name,phone_no,saved);
	}
	else if(name > Initial->ob.name)
	{
		Initial->right=Insert_Contact(Initial->right,name,phone_no,saved);
	}
	else
	{
		return Initial;
	}

	Initial->height=Get_Max(Get_Height(Initial->left),Get_Height(Initial->right))+1;
	int Bal=Get_Balance(Initial);

	if(Bal>1 && name<Initial->left->ob.name)
	{
		return Right_Rotate(Initial);
	}
	else if(Bal<-1 && name>Initial->right->ob.name)
	{
		return Left_Rotate(Initial);
	}
	else if(Bal>1 && name>Initial->left->ob.name)
	{
		Initial->left=Left_Rotate(Initial->left);
		return Right_Rotate(Initial);
	}
	else if(Bal<-1 && name<Initial->right->ob.name)
	{
		Initial->right=Right_Rotate(Initial->right);
		return Left_Rotate(Initial);
	}
	return Initial;
}

//Converts String to Integer
long long int string_to_int(string s)
{
	long long int num=0;
	for(int i=0;s[i]!='\0';i++)
	{
		num=num*10+(s[i]-'0');
	}
	return num;
}

//Searches a Contact
void Phone_Book::Search_Contact(Contact *Initial,string contact_name)
{
	if(Initial==NULL)
	{
		return;
	}
	if(contact_name[0]=='0') // if user enters a number
	{
		long long int num=string_to_int(contact_name);
		string temp=H_obj.Search_Data(num);
		obj.Search_Contact(root,temp);
	}
	else // if user enters a name
	{
		if(Initial->ob.name==contact_name)
    	{
			cout << "\n\t\t\t\t   Contact Found Successfully";
			Sleep(500);
			system("cls");
			cout << "\t\t  ::::::::::::::::::::::::::::::::::: Contact Info :::::::::::::::::::::::::::::::::::::\n\n";
			cout << "\t\t      Contact Name: " << Initial->ob.name;
			cout << "    Contact Phone No: +92 " << Initial->ob.phone_no/10000000 << " " << Initial->ob.phone_no%10000000;
			cout << "    Contact Saved in " << Initial->ob.saved;
			cout << "\n\n\t\t  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";
			Sub_Menu(Initial);
		}
		else if(contact_name<Initial->ob.name)
		{
			Search_Contact(Initial->left,contact_name);
		}
		else if(contact_name>Initial->ob.name)
		{
			Search_Contact(Initial->right,contact_name);
		}
		else
        {
            Main_Menu();
        }
	}
}

Contact* Phone_Book::Find_Max(Contact *Initial)
{
	if(Initial->right==NULL)
	{
		return Initial;
	}
	return Find_Max(Initial->right);
}

//Deletes a Contact
Contact* Phone_Book::Delete_Contact(Contact *Initial,string contact_name)
{
	if(Initial==NULL)
	{
		No_of_Contacts--;
		return Initial;
	}
	if(contact_name < Initial->ob.name)
	{
		Initial->left=Delete_Contact(Initial->left,contact_name);
	}
	else if(contact_name > Initial->ob.name)
	{
		Initial->right=Delete_Contact(Initial->right,contact_name);
	}
	else
	{
		Contact *temp=Initial;
		if(Initial->right==NULL && Initial->left==NULL)
		{
			return NULL;
		}
		else if(Initial->left!=NULL && Initial->right==NULL)
		{
			Initial=Initial->left;
			delete temp;
		}
		else if(Initial->left==NULL && Initial->right!=NULL)
		{
			Initial=Initial->right;
			delete temp;
		}
		else if(Initial->left!=NULL && Initial->right!=NULL)
		{
			Contact *pred=Find_Max(Initial->left);
			swap(pred->ob.name,Initial->ob.name);
			swap(pred->ob.phone_no,Initial->ob.phone_no);
			swap(pred->ob.saved,Initial->ob.saved);
			Initial->left=Delete_Contact(Initial->left,pred->ob.name);
		}
		else
		{
			return Initial;
		}
	}

	Initial->height=Get_Max(Get_Height(Initial->left),Get_Height(Initial->right))+1;
	int Bal=Get_Balance(Initial);

	if(Bal>1 && contact_name<Initial->left->ob.name)
	{
		return Right_Rotate(Initial);
	}
	else if(Bal<-1 && contact_name>Initial->right->ob.name)
	{
		return Left_Rotate(Initial);
	}
	else if(Bal>1 && contact_name>Initial->left->ob.name)
	{
		Initial->left=Left_Rotate(Initial->left);
		return Right_Rotate(Initial);
	}
	else if(Bal<-1 && contact_name<Initial->right->ob.name)
	{
		Initial->right=Right_Rotate(Initial->right);
		return Left_Rotate(Initial);
	}
	return Initial;

}

//Edits a contact
void Phone_Book::Edit_Contact(Contact *Initial,string contact_name)
{
	if(Initial==NULL)
	{
		return;
	}
	if(Initial->ob.name==contact_name)
	{
		char choice;
		system("cls");
		cout << "\t\t    ::::::::::::::::::::::::: Edit Contact :::::::::::::::::::::::::\n\n";
		cout << "\n\t\t\t\t\tWhat do you want to Edit ?" << endl;
		cout << "\n\t\t\t\t\t1. Contact Name\n\n\t\t\t\t\t2. Contact Number\n\n\t\t\t\t\t3. Contact Saving Location" << endl;
		re_take:
		cout << "\n\t\t\t\t\t   Enter your choice: ";
		cin >> choice;
		cout << endl;

		if(choice!='1' && choice!='2' && choice!='3')
		{
			cout << "\nInvalid Choice" << endl;
			goto re_take;
		}

		switch(choice)
		{
			case '1':
			{
				string rename;
				re_name:
				cout << "\n\t\t\t\t-> Enter New Contact Name(15 char max): ";
                fflush(stdin);
	            getline(cin,rename);
	            if(rename[0]>='0' && rename[0]<='9')
                {
                    cout << "\n\n\t\t\t\t\t    ERROR! Contact Name Invalid\n" << endl;
					goto re_name;
                }
				if(rename.length()>15)
				{
					cout << "\n\n\t\t\t\t\t    ERROR! Contact Name Size Exceeded\n" << endl;
					goto re_name;
				}
				flag=false;
				Check_Duplicate(root,rename);
				if(flag==true)
				{
					rename.append("(1)");
				}
				long long int temp1=Initial->ob.phone_no;
				string temp2=Initial->ob.saved;
                system("cls");
			    cout << "\t\t  ::::::::::::::::::::::::::::::::::: Contact Info :::::::::::::::::::::::::::::::::::::\n\n";
			    cout << "\t\t      Contact Name: " << rename;
			    cout << "    Contact Phone No: +92 " << Initial->ob.phone_no/10000000 << " " << Initial->ob.phone_no%10000000;
			    cout << "    Contact Saved in " << Initial->ob.saved;
			    cout << "\n\n\t\t  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";
                Edit_Call_Log(Initial->ob.name,rename);
				root=obj.Delete_Contact(root,Initial->ob.name);
				root=obj.Insert_Contact(root,rename,temp1,temp2);
				H_obj.Edit_Data(temp1,rename,temp2);
				No_of_Contacts--;
				break;
			}
			case '2':
			 {

			    long long int phone_no;
				do
				{
					cout << "\n\t\t\t\t-> Enter new contact number: ";
					cin >> phone_no;
	    			if(num_valid(phone_no)==false)
	    			{
	    				cout << "\n\n\t\t\t\t\t    Invalid Contact Number\n" << endl;
					}
				}
				while(!num_valid(phone_no));
                system("cls");
			    cout << "\t\t  ::::::::::::::::::::::::::::::::::: Contact Info :::::::::::::::::::::::::::::::::::::\n\n";
			    cout << "\t\t      Contact Name: " << Initial->ob.name;
			    cout << "    Contact Phone No: +92 " << phone_no/10000000 << " " << phone_no%10000000;
			    cout << "    Contact Saved in " << Initial->ob.saved;
			    cout << "\n\n\t\t  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";
			    string no="0";
                Edit_Call_Log(no.append(to_string(Initial->ob.phone_no)),no.append(to_string(phone_no)));
				H_obj.Delete_Data(Initial->ob.phone_no);
				Initial->ob.phone_no=phone_no;
				H_obj.Insert_Data(Initial->ob.name,Initial->ob.phone_no,Initial->ob.saved);
				break;
		    }
			case '3':
				char ch;
				re_sim:
				cout << "\n\t\t\t\t\t-> Where do you want to save the Sim: \n\n\t\t\t\t\t   1. SIM1 \n\t\t\t\t\t   2. SIM2\n\n\t\t\t\t\t-> Choice: ";
				cin >> ch;
				if(ch!='1' && ch!='2')
				{
	    			cout << "\n\n\t\t\t\t\t  Invalid Choice\n" << endl;
	    			goto re_sim;
				}
				if(ch=='1')
				{
					Initial->ob.saved="SIM1";
				}
				else
				{
					Initial->ob.saved="SIM2";
				}
                system("cls");
			    cout << "\t\t  ::::::::::::::::::::::::::::::::::: Contact Info :::::::::::::::::::::::::::::::::::::\n\n";
			    cout << "\t\t      Contact Name: " << Initial->ob.name;
			    cout << "    Contact Phone No: +92 " << Initial->ob.phone_no/10000000 << " " << Initial->ob.phone_no%10000000;
			    cout << "    Contact Saved in " << Initial->ob.saved;
			    cout << "\n\n\t\t  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";
				H_obj.Edit_Data(Initial->ob.phone_no,Initial->ob.name,Initial->ob.saved);
				break;
		}
	}
	else if(contact_name < Initial->ob.name)
	{
		Edit_Contact(Initial->left,contact_name);
	}
	else if(contact_name > Initial->ob.name)
	{
		Edit_Contact(Initial->right,contact_name);
	}
}

//Call Log Stack
class Stack{
    public:
        string arr[S_Size];
        int Size;
        int top;
        Stack()
        {
            Size=0;
            top=-1;
        }
        bool Empty()
        {
            if(top<0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        bool Full()
        {
            if(top>Size-1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        void Push(string data)
        {
            if(Full())
            {
                cout << "Error";
                return;
            }
            else
            {
                Size++;
                arr[++top]=data;
            }
        }
        string Pop()
        {
            if(Empty())
            {
                cout << "Error";
                return NULL;
            }
            else
            {
                return arr[top--];
            }
        }
}S_obj;

//Calls A Contact
void Phone_Book::Call_Contact(Contact *Initial)
{
    cout << "\n\n\t\t\t\t\t";
    string c="Calling ";
    c.append(Initial->ob.name);
    c.append( " .....");
    for(int i=0;c[i]!='\0';i++)
    {
        Sleep(250);
        cout << c[i];
    }
    S_obj.Push(Initial->ob.name);
}

//Restores Call log data
void ReInitialize_Call_Log(vector<string> arr)
{
    for (auto i = arr.rbegin(); i != arr.rend(); ++i)
    {
        S_obj.Push(*i);
    }
}

//Displays the Call log
void Display_Call_Log()
{
    vector<string>arr;
    while(!S_obj.Empty())
    {
        string s=S_obj.Pop();
        arr.push_back(s);
        if(s[0]=='0' && s!="")
        cout << "\t\t\t     -------------------> " << s << " <--------------------" << endl;
        else if(s[0]!='0' && s!="")
        cout << "\t\t\t          -----------------> " << s << " <--------------------" << endl;
    }
    ReInitialize_Call_Log(arr);
}

//Edit the Call Log
void Edit_Call_Log(string oldvalue,string revalue)
{
    vector<string>arr;
    while(!S_obj.Empty())
    {
        string s=S_obj.Pop();
        if(s==oldvalue)
        {
            arr.push_back(revalue);
        }
        else
        {
            arr.push_back(s);
        }
    }

    for (auto i = arr.rbegin(); i != arr.rend(); ++i)
    {
        S_obj.Push(*i);
    }
}

//Update Call Log after Contact Deleted/Blocked
void Update_Post_Task(Contact *Initial,string task)
{
    vector<string> arr;
    string st="0";

    if(task=="DELETE")
    {
        while(!S_obj.Empty())
        {
           string a;
           a=S_obj.Pop();
           if(a!=Initial->ob.name)
           {
              arr.push_back(a);
           }
           else
           {
              arr.push_back(st.append(to_string(Initial->ob.phone_no)));
           }
        }
    }
    else if(task=="BLOCK")
    {
        while(!S_obj.Empty())
        {
           string a;
           a=S_obj.Pop();
           if(a!=Initial->ob.name)
           {
              arr.push_back(a);
           }
           else
           {
              arr.push_back("");
           }
        }
    }

    for (auto i = arr.rbegin(); i != arr.rend(); ++i)
    {
        S_obj.Push(*i);
    }
}

//Updates Call Log after Unblocking Contact
void Update_Post_UnBlock(string contact_name)
{
    vector<string> arr;
    while(!S_obj.Empty())
    {
        string a;
        a=S_obj.Pop();
        if(a=="")
        {
            arr.push_back(contact_name);
        }
        else
        {
              arr.push_back(a);
        }
    }
    for (auto i = arr.rbegin(); i != arr.rend(); ++i)
    {
        S_obj.Push(*i);
    }
}

//Shows sub menu after contact searched
void Sub_Menu(Contact *Initial)
{
	char choice;
	cout << "\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 1. Delete this Contact\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 2. Edit this Contact\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 3. Block this Contact\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 4. Call this Contact\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 5. Return to Main Menu";
	re_menu:
	cout << "\n\n\t\t\t\t-> Enter Your Choice: ";
	cin >> choice;

	if(choice!='1' && choice!='2' && choice!='3' && choice!='4' && choice!='5')
	{
		cout << "\n\nt\t\t\t  Invalid Choice\n" << endl;
		goto re_menu;
	}

	switch(choice)
	{
		case '1':
            Update_Post_Task(Initial,"DELETE");
			root=obj.Delete_Contact(root,Initial->ob.name);
			H_obj.Delete_Data(Initial->ob.phone_no);
			cout << "\n\t\t\t    Contact Deleted Successfully";
			Sleep(500);
			system("cls");
			cout << "\t\t    ::::::::::::::::::::::::: Displaying All Contacts :::::::::::::::::::::::::\n\n";
	        disp=1;
            cout << "\t\t\t\t   ===========================================\n";
			obj.Display_Contacts(root);
			break;
		case '2':
			obj.Edit_Contact(root,Initial->ob.name);
			Sub_Menu(Initial);
			break;
		case '3':
		    Update_Post_Task(Initial,"BLOCK");
			B_obj.Save_BlockList(Initial);
			B_obj.Block_Contact(Initial);
			cout << "\n\t\t\t    Contact Blocked Successfully";
			Sleep(500);
			system("cls");
			cout << "\t\t    ::::::::::::::::::::::::: Displaying All Contacts :::::::::::::::::::::::::\n\n";
	        disp=1;
            cout << "\t\t\t\t   ===========================================\n";
			obj.Display_Contacts(root);
			break;
		case '4':
			obj.Call_Contact(Initial);
			system("cls");
            cout << "\t\t  ::::::::::::::::::::::::::::::::::: Contact Info :::::::::::::::::::::::::::::::::::::\n\n";
            cout << "\t\t      Contact Name: " << Initial->ob.name;
            cout << "    Contact Phone No: +92 " << Initial->ob.phone_no/10000000 << " " << Initial->ob.phone_no%10000000;
            cout << "    Contact Saved in " << Initial->ob.saved;
            cout << "\n\n\t\t  ::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::\n\n";
			Sub_Menu(Initial);
			break;
		case '5':
            Main_Menu();
	}
}

//Check Contact Duplicates
void Check_Duplicate(Contact *Initial,string contact_name)
{
	if(Initial==NULL)
	{
		return;
	}
	if(Initial->ob.name==contact_name)
    {
		flag=true;
	}
	else if(contact_name<Initial->ob.name)
	{
		Check_Duplicate(Initial->left,contact_name);
	}
	else if(contact_name>Initial->ob.name)
	{
		Check_Duplicate(Initial->right,contact_name);
	}

}

// Saving Contacts in a File
void Save_Contacts(Contact *Initial)
{
    ofstream fout("Contact_List.txt",ios::app);
    fout << Initial->ob.name << " +92 " << Initial->ob.phone_no/10000000 << " " <<  Initial->ob.phone_no%10000000 << " " << Initial->ob.saved << endl;
    fout.close();
}

//Displays all Contacts
void Phone_Book::Display_Contacts(Contact *Initial)
{
	if(Initial==NULL)
	{
		return;
	}
	Display_Contacts(Initial->left);
	cout << "\t\t\t\t   |\t      " <<disp << ". "<< Initial->ob.name << endl;
	cout << "\t\t\t\t   ===========================================\n";
	Save_Contacts(Initial);
	disp++;
	Display_Contacts(Initial->right);
}

//Saving Contacts Initially
void Save_Pre_Contacts()
{
    ifstream fin("Data_Set.txt");
    string name,saved,phone_no;
    while(!fin.eof())
    {
        getline(fin,name);
        getline(fin,phone_no);
        getline(fin,saved);
        if(name!="")
        root=obj.Insert_Contact(root,name,string_to_int(phone_no),saved);
    }
    fin.close();
}

//Validates that number is 10 digits long (excluding zero)
bool num_valid(long long int no)
{
	int count=0;
	while(no!=0)
	{
		no/=10;
		count++;
	}
	if(count==10)return true;
	else return false;
}

//Takes Info of a Contact
void Take_Data()
{
	string name,saved;
	long long int no;
	char choice;

	re_name:
	cout << "\n\t\t\t-> Enter Contact Name(15 char max): ";
	fflush(stdin);
	getline(cin,name);
    if(name[0]>='0' && name[0]<='9')
    {
        cout << "\n\n\t\t\t\t\t    ERROR! Contact Name Invalid\n" << endl;
        goto re_name;
    }
	if(name.length()>15)
	{
		cout << "\n\n\t\t\t\t    ERROR! Contact Name Size Exceeded\n" << endl;
		goto re_name;
	}

	flag=false;
	Check_Duplicate(root,name);
	if(flag==true)
	{
		name.append("(1)");
	}

    do
	{
		cout << "\n\t\t\t-> Enter Contact Number: ";
	    cin >> no;
	    if(num_valid(no)==false)
	    {
	    	cout << "\n\n\t\t\t\t    Invalid Contact Number\n" << endl;
		}
	}
	while(!num_valid(no));

	re_sim:
	cout << "\n\t\t\t-> Where do you want to save the Sim: \n\n\t\t\t   1.SIM1 \n\t\t\t   2.SIM2\n\n\t\t\t-> Choice: ";
	cin >> choice;
	if(choice!='1' && choice!='2')
	{
	    cout << "\n\n\t\t\t\t  Invalid Choice\n" << endl;
	    goto re_sim;
	}

	if(choice=='1')
	{
		saved="SIM1";
	}
	else
	{
		saved="SIM2";
	}
	if(name[0]>='a' && name[0]<='z')name[0]-=32;
	obj.Insert_Contact(root,name,no,saved);
}

//Main Display Menu
void Main_Menu()
{
	char choice;
	system("cls");
	cout << "\n  \t\t\t::::::::::::::::::::::::::::  PHONE BOOK  :::::::::::::::::::::::::::  \n";
	cout << " \n                            =============================================================";
	cout << "\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 1. Insert Contact\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 2. Display All Contacts\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 3. Display Block List\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 4. Display Call Log\n\n\t\t               \xDB\xDB\xDB\xDB\xB2 5. Exit";
	cout << "\n\n                           =============================================================\n";
	re_input:
	cout << "\n\n\t\t\t\t-> Enter Your Choice: ";
	cin >> choice;
	if(choice!='1' && choice!='2' && choice!='3' && choice!='4' && choice!='5')
	{
		cout << "\nInvalid Choice" << endl;
		goto re_input;
	}
	switch(choice)
	{
		case '1':
			system("cls");
			cout << "\t\t    ::::::::::::::::::::::::: Contact Details :::::::::::::::::::::::::\n\n";
			Take_Data();
			getch();
			Main_Menu();
			break;
		case '2':
		{

			system("cls");
	        cout << "\t\t    ::::::::::::::::::::::::: Displaying All Contacts :::::::::::::::::::::::::\n\n";
	        disp=1;
	        ofstream fout("Contact_List.txt",ios::trunc);//Needs to refresh the file with updated contacts
	        fout.close();
            cout << "\t\t\t\t   ===========================================\n";
		    obj.Display_Contacts(root);
		    getch();
		    string contact_name;
            cout << "\n\t\t\t\t   Search a contact among " << No_of_Contacts << " contacts: ";
            fflush(stdin);
	        getline(cin,contact_name);
	        if(contact_name[0]>='a' && contact_name[0]<='z')contact_name[0]-=32;
	        obj.Search_Contact(root,contact_name);
	        getch();
		    Main_Menu();
		    break;
		}
		case '3':
		{
			system("cls");
	        cout << "\t\t    ::::::::::::::::::::::::: Displaying Blocked Contacts :::::::::::::::::::::::::\n\n";
	        if(Blocked_Contacts!=0)
	        cout << "\t\t\t\t   ===========================================\n";
			B_obj.Display_BlockList();
			if(Blocked_Contacts!=0)
            {
                getch();
			    string contact_name;
                cout << "\n\t\t\t\t     UnBlock a contact among " << Blocked_Contacts << " contacts: ";
                fflush(stdin);
                getline(cin,contact_name);
                if(contact_name[0]>='a' && contact_name[0]<='z')contact_name[0]-=32;
                Update_Post_UnBlock(contact_name);
                B_obj.Unblock_Contact(contact_name);
            }
            else
            {
                cout << "\n\t\t\t\t\t         No Blocked Contacts";
            }
			getch();
			Main_Menu();
			break;
		}
		case '4':
        {
            system("cls");
            cout << "\t\t    ::::::::::::::::::::::::: Displaying Call Log :::::::::::::::::::::::::\n\n";
            Display_Call_Log();
            getch();
            Main_Menu();
            break;
        }
        case '5':
            system("cls");
            exit(1);
            break;
	}
}

void Print_Front()
{
    system("COLOR 70");
    string s;
    ifstream fin1("LOGO.txt");
    while(!fin1.eof())
    {
        getline(fin1,s);
        Sleep(250);
        cout << s << endl;
    }
    fin1.close();
    Sleep(1000);
    system("cls");
}

int main()
{
    Print_Front();
	Save_Pre_Contacts();
	Main_Menu();
}
